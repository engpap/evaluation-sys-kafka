package models

type Student struct {
	ID string `json:"id"`
}
