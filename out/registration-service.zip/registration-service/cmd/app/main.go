package main

import (
	"eval-sys-registration-service/cmd/internal/transport"
)

func main() {
	transport.Serve()
}
