package models

type Enrollment struct {
	StudentID string `json:"student_id"`
	CourseID  string `json:"course_id"`
}
