package main

import "eval-sys-course-service/cmd/internal/transport"

func main() {
	transport.Serve()
}
