package main

import (
	"eval-sys-project-service/cmd/internal/transport"
)

func main() {
	transport.Serve()
}
