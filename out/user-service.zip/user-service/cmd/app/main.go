package main

import "eval-sys-user-service/cmd/internal/transport"

func main() {
	transport.Serve()
}
