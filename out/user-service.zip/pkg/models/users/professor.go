package models

type Professor struct {
	ID string `json:"id"`
}
